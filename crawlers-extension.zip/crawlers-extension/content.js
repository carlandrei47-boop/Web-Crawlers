(() => {
if (window.__crawlerLoaded) return; window.__crawlerLoaded = 1;
console.log('[Crawlers v2.4] running on', location.href);
const api = globalThis.browser || globalThis.chrome, R = Math.random, TAU = 6.2832;
const C = { b: '#3b5bff', y: '#ffd400', r: '#e0301e', p: '#ff4d8d', c: '#27d3c3', g: '#7dff2a', o: '#ff8a1f', w: '#dff3ff' }, PAL = [C.p, C.c, C.g, C.y];
const tierOf = xp => xp > 200 ? { n: 'Legendary', c: '#9d00ff', s: 1.3 } : xp > 80 ? { n: 'Shadow', c: C.p, s: 1.18 } : xp > 30 ? { n: 'Electric', c: C.y, s: 1.08 } : { n: 'Baby', c: C.c, s: 1 };
let on = false, species = 'random', power = 'random', host, cv, x, raf, W, H, D, tx, ty, last = 0, fr = 0, crit, xp = 0, boost = 0;
let ledges = [], temps = [], pool = [], infected = [], infT = null, bridges = [];
let spans = [], debris = [], parts = [], rings = [], webs = [], threads = [], traps = [], plats = [], platT = 0, visualHits = [];

// ---------- words ----------
function grab(px, py) {
  let r;
  if (document.caretPositionFromPoint) { const p = document.caretPositionFromPoint(px, py); if (!p) return; r = document.createRange(); r.setStart(p.offsetNode, p.offset); r.collapse(true); }
  else if (document.caretRangeFromPoint) r = document.caretRangeFromPoint(px, py);
  if (!r) return;
  const n = r.startContainer; if (n.nodeType !== 3) return;
  const el = n.parentElement;
  if (!el || el.closest('input,textarea,select,[contenteditable],script,style,svg,canvas')) return;
  const near = b => !(px < b.left - 14 || px > b.right + 14 || py < b.top - 14 || py > b.bottom + 14);
  if (el.dataset.crawl) return el.dataset.t || !near(el.getBoundingClientRect()) ? undefined : el;
  const t = n.data; let a = r.startOffset, b = a;
  while (a > 0 && /\S/.test(t[a - 1])) a--;
  while (b < t.length && /\S/.test(t[b])) b++;
  if (b - a < 2 || b - a > 24) return;
  const rg = document.createRange(); rg.setStart(n, a); rg.setEnd(n, b);
  const bb = rg.getBoundingClientRect(); if (!bb.width || !near(bb)) return;
  const s = document.createElement('span'); s.dataset.crawl = '1'; s.dataset.o = t.slice(a, b);
  try { rg.surroundContents(s); } catch (e) { return; }
  spans.push(s); return s;
}
function burst(px, py, n, c, g) { for (let i = 0; i < n && parts.length < 500; i++) { const a = R() * TAU, v = 1 + R() * 3.5; parts.push({ x: px, y: py, vx: Math.cos(a) * v, vy: Math.sin(a) * v, l: 1, c, g: g || 0 }); } }
function ring(px, py, m, c) { rings.push({ x: px, y: py, r: 4, m, c, l: 1 }); }
function toss(s, txt, kind, o) {
  o = o || {}; kind = kind || 'label';
  if (kind === 'label' && debris.filter(d => d.t === txt && d.k === 'label').length >= 2) return;
  if (debris.length > 120) debris.shift();
  const b = s.getBoundingClientRect(), cs = getComputedStyle(s), fs = parseFloat(cs.fontSize) || 14, item = kind !== 'label';
  const font = cs.fontStyle + ' ' + cs.fontWeight + ' ' + fs + 'px ' + cs.fontFamily; x.font = font;
  debris.push({ b: performance.now(), t: txt, k: kind, font, h: item ? 12 : fs + 6, w: item ? 12 : x.measureText(txt).width + 8,
    px: b.left + scrollX + (item ? b.width / 2 : 0), py: b.top + scrollY + b.height / 2,
    vx: o.vx != null ? o.vx : (R() - .5) * 9, vy: o.vy != null ? o.vy : (R() - .5) * 9, g: o.g || 0, pull: o.pull ? .14 : 0,
    rot: item ? 0 : (R() - .5) * .8, vr: item ? 0 : (R() - .5) * .12, c: o.col || PAL[R() * 4 | 0] });
}
function wipe(s, kind, o) {
  if (s.dataset.t) return; s.dataset.t = 1; xp++;
  const b = s.getBoundingClientRect(); burst(b.left + b.width / 2, b.top + b.height / 2, kind === 'boom' ? 16 : 8, (o && o.col) || PAL[R() * 4 | 0]);
  if (kind === 'boom') { s.style.setProperty('visibility', 'hidden', 'important'); return; }
  toss(s, s.textContent, kind, o); s.style.setProperty('visibility', 'hidden', 'important');
}
function restoreAll() {
  restoreVisuals();
  for (const s of spans) { if (!s.isConnected) continue; const p = s.parentNode; s.replaceWith(document.createTextNode(s.dataset.o)); p && p.normalize && p.normalize(); }
  clearInterval(infT); infT = null; infected = []; pool = []; bridges = []; temps = [];
  spans = []; debris = []; parts = []; rings = []; webs = []; threads = []; traps = [];
}

// ---------- pictures / boxes ----------
function undoVisual(v) { if (!v.done) { v.done = 1; if (v.el.isConnected) { v.o === null ? v.el.removeAttribute('style') : v.el.setAttribute('style', v.o); v.el.removeAttribute('data-crawlv'); } } }
function restoreVisuals() { visualHits.forEach(undoVisual); visualHits = []; }
function hitVisual(px, py) {
  const list = (document.elementsFromPoint ? document.elementsFromPoint(px, py) : []).filter(e => e !== host && e.tagName !== 'HTML' && !e.dataset.crawlv);
  if (!list.length) return;
  const el = list[R() * Math.min(3, list.length) | 0], modes = ['rainbow', 'bounce', 'neon', 'matrix', 'glitch', 'tilt'], mode = power === 'random' ? modes[R() * 6 | 0] : power, st = el.style;
  const v = { el, o: el.getAttribute('style') }; visualHits.push(v); el.dataset.crawlv = '1';
  st.setProperty('transition', 'filter .4s ease, transform .4s ease', 'important');
  if (mode === 'rainbow') st.setProperty('filter', 'hue-rotate(' + (R() * 360 | 0) + 'deg) saturate(1.5)', 'important');
  else if (mode === 'bounce') st.setProperty('transform', 'translateY(-4px) scale(1.03)', 'important');
  else if (mode === 'neon') st.setProperty('filter', 'drop-shadow(0 0 8px ' + PAL[R() * 4 | 0] + ') saturate(1.4)', 'important');
  else if (mode === 'matrix') st.setProperty('filter', 'hue-rotate(90deg) saturate(2.2) contrast(1.15)', 'important');
  else if (mode === 'tilt') st.setProperty('transform', 'rotate(' + ((R() - .5) * 4).toFixed(1) + 'deg)', 'important');
  else st.setProperty('filter', 'contrast(2) invert(.8)', 'important');
  setTimeout(() => undoVisual(v), 8000);
}

// ---------- invisible text platform tracking ----------
function buildPlats() {
  const out = [], tw = document.createTreeWalker(document.body || document.documentElement, NodeFilter.SHOW_TEXT); let n, seen = 0;
  while ((n = tw.nextNode()) && seen++ < 4000) {
    if (!/\S/.test(n.data)) continue;
    const p = n.parentElement; if (!p || /^(SCRIPT|STYLE|NOSCRIPT)$/.test(p.tagName)) continue;
    const rg = document.createRange(); rg.selectNodeContents(n);
    for (const r of rg.getClientRects()) if (r.width > 24 && r.height > 6 && r.bottom > 0 && r.top < H && r.right > 0 && r.left < W) out.push({ l: r.left, r: r.right, t: r.top });
    if (out.length > 1500) break;
  }
  plats = out.concat(ledges);
}
function makeLedges() {
  ledges = [];
  for (let y = H - 85, row = 0; y > 30; y -= 85, row++) { let xx = (row % 2) * 90 + R() * 60; while (xx < W) { const wd = 110 + R() * 90; ledges.push({ l: xx, r: Math.min(W, xx + wd), t: y + (R() - .5) * 14 }); xx += wd + 90 + R() * 120; } }
}
function walker() { return { x: W * (.25 + R() * .5), y: H * .3, vx: 0, vy: 0, face: 1, ground: false, drop: 0, jc: 0, hit: 0, st: 0, bt: 0, lx: null }; }
function warp(w, gx, gy) {
  let best = null, bs = 1e9;
  for (const p of plats) { if (p.t < 20 || p.t > H - 40) continue; const sc = Math.abs(p.t - gy) + Math.abs((p.l + p.r) / 2 - gx) * .4; if (sc < bs) { bs = sc; best = p; } }
  if (best) { burst(w.x, w.y, 14, C.w); w.x = (best.l + best.r) / 2; w.y = best.t - 2; w.vy = 0; w.vx = 0; burst(w.x, w.y, 14, C.w); }
  w.bt = 0;
}
function phys(w, run, jump, free) {
  const gx = w.tx != null ? w.tx : tx, gy = w.ty != null ? w.ty : ty; let tgx = gx;
  const all = temps.length ? plats.concat(temps) : plats;
  if (!free && w.ground && gy < w.y - 40) {
    let best = null, bs = 1e9;
    for (let pass = 0; pass < 2 && !best; pass++) {
      const lim = pass ? 1e9 : 170;
      for (const p of all) { const dy = w.y - p.t; if (dy < 18 || dy > 105) continue; const m = Math.min(24, (p.r - p.l) / 2), cx = Math.max(p.l + m, Math.min(p.r - m, w.x)), dxp = Math.abs(cx - w.x); if (dxp > lim) continue; const sc = dxp + Math.abs(p.t - gy) * .6 + Math.abs((p.l + p.r) / 2 - gx) * .15; if (sc < bs) { bs = sc; best = { x: cx }; } }
    }
    w.nav = best;
  } else if (w.ground) w.nav = null;
  if (w.nav) tgx = w.nav.x; else if (!w.ground && w.navx != null) tgx = w.navx;
  const dx = tgx - w.x;
  if (!free) { const want = Math.abs(dx) > 10 ? Math.sign(dx) * (w.nav && Math.abs(dx) < 40 ? Math.max(1.2, Math.abs(dx) * .12) : run) : 0; w.vx += (want - w.vx) * (w.ground ? .25 : .08); if (want) w.face = Math.sign(dx); }
  w.jc--; if (!free && w.ground && w.jc <= 0 && gy < w.y - 36 && (!w.nav || (Math.abs(dx) < 12 && Math.abs(w.vx) < 1.6) || (Math.sign(w.vx) === Math.sign(dx) && Math.abs(dx) < Math.max(14, Math.abs(w.vx) * 24)))) { w.vy = -jump; w.ground = false; w.jc = 25; w.navx = w.nav ? w.nav.x : null; }
  if (!free && w.ground && gy > w.y + 50 && R() < .04) w.drop = 14;
  if (!free) {
    if (w.lx != null && Math.abs(w.x - w.lx) < .5 && Math.abs(gx - w.x) > 40) w.st++; else w.st = 0; w.lx = w.x;
    if (w.st > 70) { w.vy = -15; w.vx = (R() - .5) * 14; w.st = 0; w.ground = false; }
    if (w.y >= H - 1 && gy < H - 120) w.bt++; else w.bt = 0;
    if (w.bt > 150) warp(w, gx, gy);
  }
  w.vy = Math.min(w.vy + .62, 18); const py = w.y; w.x += w.vx; w.y += w.vy; if (w.drop > 0) w.drop--;
  w.ground = false; w.hit = 0;
  if (w.vy >= 0 && !w.drop) {
    let best = null;
    for (const p of all) if (w.x > p.l - 3 && w.x < p.r + 3 && py <= p.t + 1 && w.y >= p.t && (!best || p.t < best.t)) best = p;
    if (best) { w.hit = w.vy; w.y = best.t; w.vy = 0; w.ground = true; w.navx = null; }
  }
  if (w.y >= H) { w.hit = w.vy; w.y = H; w.vy = 0; w.ground = true; w.navx = null; }
  w.x = Math.max(10, Math.min(W - 10, w.x)); if (w.y < 26) { w.y = 26; if (w.vy < 0) w.vy = 0; }
}

function steer(h, max) {
  const dx = tx - h.x, dy = ty - h.y, d = Math.hypot(dx, dy) || 1;
  let da = Math.atan2(dy, dx) - h.a; da = Math.atan2(Math.sin(da), Math.cos(da)); h.a += da * .09;
  const sp = Math.min(d * .06, max * (1 + boost * 1.6)); h.x += Math.cos(h.a) * sp; h.y += Math.sin(h.a) * sp;
}
function line(a, b, c, d) { x.moveTo(a, b); x.lineTo(c, d); }
const rnd = (cx, cy, r) => { const a = R() * TAU, d = R() * r; return [cx + Math.cos(a) * d, cy + Math.sin(a) * d]; };

// ---------- CENTIPEDE ----------
function snippet() {
  let t = pool[R() * pool.length | 0] || '???'; if (R() < .35) t += ' ' + (pool[R() * pool.length | 0] || '');
  return R() < .3 ? t.split('').map(c => R() < .25 ? '#%&@$*?!'[R() * 8 | 0] : c).join('') : t;
}
function infTick() {
  for (const s of infected) {
    if (!s.isConnected || s.dataset.v == 2 || s.dataset.t) continue;
    if (R() < .22) { const old = s.textContent; s.textContent = snippet(); s.style.setProperty('opacity', (.55 + R() * .45).toFixed(2), 'important'); if (R() < .08 && old.length > 1 && on) toss(s, old, 'label', { g: .3, col: C.g, vx: (R() - .5) * 2, vy: -1 }); }
  }
}
function infect(s) {
  if (s.dataset.t || s.dataset.v) return; s.dataset.v = 1;
  pool.push(s.dataset.o); if (pool.length > 300) pool.splice(0, 50);
  const st = s.style; st.setProperty('color', C.g, 'important'); st.setProperty('text-shadow', '0 0 6px ' + C.g, 'important');
  const b = s.getBoundingClientRect(); burst(b.left + b.width / 2, b.top + b.height, 5, C.g, .25);
  infected.push(s); if (infected.length > 500) { const o = infected.shift(); o.dataset.v = 2; }
  if (!infT) infT = setInterval(infTick, 380);
}
function centipede() {
  const N = 15, S = 20, seg = [], legs = [];
  for (let i = 0; i < N; i++) seg.push({ x: W * .5 - i * S, y: H * .5, a: 0 });
  seg.forEach((s, i) => { if (i) for (const k of [-1, 1]) legs.push({ s, i, k, fx: s.x, fy: s.y + k * 20, tx: 0, ty: 0, sx: 0, sy: 0, t: 1, hx: 0, hy: 0 }); });
  return {
    col: C.g, tiered: true, vac: true, pts: () => seg,
    click(px, py) { ring(px, py, 150, C.g); burst(px, py, 30, C.g, .15); boost = 1; for (let i = 0; i < 14; i++) setTimeout(() => { const p = rnd(px, py, 130), s = grab(p[0], p[1]); s && infect(s); }, i * 60); },
    update() {
      const h = seg[0]; steer(h, 3.4);
      for (let i = 1; i < N; i++) { const p = seg[i - 1], s = seg[i], a = Math.atan2(p.y - s.y, p.x - s.x); s.a = a; s.x = p.x - Math.cos(a) * S; s.y = p.y - Math.sin(a) * S; }
      if (fr % 3 == 0) { const b = seg[(fr / 3 | 0) % N], p = rnd(b.x, b.y, 22), s = grab(p[0], p[1]); s && infect(s); }
      if (fr % 4 == 0) { const b = seg[R() * N | 0]; parts.push({ x: b.x, y: b.y, vx: (R() - .5) * .6, vy: .3, l: 1, c: C.g, g: .04 }); }
      for (const l of legs) {
        const s = l.s, c = Math.cos(s.a), n = Math.sin(s.a), L = l.i >= N - 2 ? 46 : 32;
        l.hx = s.x - n * l.k * 7; l.hy = s.y + c * l.k * 7;
        if (l.t >= 1) { if (Math.hypot(l.hx - l.fx, l.hy - l.fy) > L) { l.sx = l.fx; l.sy = l.fy; l.tx = l.hx + c * L * .6 - n * l.k * L * .7; l.ty = l.hy + n * L * .6 + c * l.k * L * .7; l.t = 0; } }
        else { l.t = Math.min(1, l.t + .14); l.fx = l.sx + (l.tx - l.sx) * l.t; l.fy = l.sy + (l.ty - l.sy) * l.t; if (l.t >= 1) { const p = rnd(l.fx, l.fy, 26), s2 = grab(p[0], p[1]); s2 && infect(s2); } }
      }
    },
    draw(now) {
      const h = seg[0];
      x.lineWidth = .6; x.strokeStyle = C.g; x.globalAlpha = .35; x.beginPath();
      for (let j = 2; j < legs.length; j++) { line(legs[j].fx, legs[j].fy, legs[j - 2].fx, legs[j - 2].fy); line(legs[j].fx, legs[j].fy, legs[j - 1].fx, legs[j - 1].fy); }
      x.stroke(); x.globalAlpha = 1; x.lineWidth = 1.2;
      for (const l of legs) {
        const c = Math.cos(l.s.a), n = Math.sin(l.s.a), kx = (l.hx + l.fx) / 2 - n * l.k * 9, ky = (l.hy + l.fy) / 2 + c * l.k * 9;
        x.strokeStyle = C.g; x.beginPath(); line(l.hx, l.hy, kx, ky); x.lineTo(l.fx, l.fy); x.stroke();
        x.fillStyle = C.y; x.beginPath(); x.arc(l.fx, l.fy, l.t < 1 ? 3 : 2, 0, 7); x.fill();
      }
      for (let i = N - 1; i >= 0; i--) {
        const s = seg[i], w = Math.sin(now / 160 - i * .7) * 3; x.save(); x.translate(s.x - Math.sin(s.a) * w, s.y + Math.cos(s.a) * w); x.rotate(s.a);
        x.fillStyle = i ? C.y : C.r; x.globalAlpha = i ? .85 : 1; x.fillRect(-S / 2 + 2, -7, S - 4, 14); x.globalAlpha = 1;
        x.strokeStyle = C.g; x.lineWidth = 1.5; x.strokeRect(-S / 2 + 2, -7, S - 4, 14); x.lineWidth = 1; x.strokeRect(-3, -4, 6, 8); x.restore();
      }
      x.strokeStyle = C.g; x.lineWidth = 1;
      for (const k of [-1, 1]) { const a = h.a + k * .5 + Math.sin(now / 200 + k) * .25; x.beginPath(); line(h.x + Math.cos(h.a) * 9, h.y + Math.sin(h.a) * 9, h.x + Math.cos(a) * 34, h.y + Math.sin(a) * 34); x.stroke(); }
    }
  };
}

// ---------- SPIDER ----------
function swapPair(br) {
  const A = br.a, B = br.b, ta = A.textContent, tb = B.textContent, r = R();
  if (r < .55) { A.textContent = tb; B.textContent = ta; }
  else if (r < .8) { const h = t => Math.ceil(t.length / 2); A.textContent = ta.slice(0, h(ta)) + tb.slice(h(tb)); B.textContent = tb.slice(0, h(tb)) + ta.slice(h(ta)); }
  else { (R() < .5 ? A : B).textContent = pool[R() * pool.length | 0] || ta; }
  xp++;
}
function bridge(from) {
  if (bridges.length >= 8) return;
  const ok = q => q && !q.dataset.t && !q.dataset.w && !q.dataset.b && !q.dataset.v;
  const p1 = rnd(from.x, from.y, 170), a = grab(p1[0], p1[1]), ang = R() * TAU, d = 220 + R() * 400, b = grab(from.x + Math.cos(ang) * d, from.y + Math.sin(ang) * d);
  if (!ok(a) || !ok(b) || a === b) return;
  for (const q of [a, b]) { q.dataset.b = 1; pool.push(q.dataset.o); q.style.setProperty('color', C.c, 'important'); q.style.setProperty('border-bottom', '1px solid ' + C.c, 'important'); }
  if (pool.length > 300) pool.splice(0, 50);
  bridges.push({ a, b, l: 0, src: from, pulses: [{ p: 0, d: 1 }, { p: .5, d: -1 }] });
}
function web(s, from) {
  if (s.dataset.t || s.dataset.w || s.dataset.b || s.dataset.v) return; s.dataset.w = 1;
  const st = s.style; st.setProperty('text-decoration', 'line-through', 'important'); st.setProperty('color', C.w, 'important'); st.setProperty('opacity', '.7', 'important');
  webs.push({ p: from, s, l: 0 });
}
function spider() {
  const h = { x: W / 2, y: H / 2, a: 0 }, ab = { x: h.x - 26, y: h.y, a: 0 }, legs = [], trail = [];
  for (const k of [-1, 1]) for (let j = 0; j < 4; j++) legs.push({ k, ang: k * (.55 + j * .42), L: 96 - j * 4, fx: h.x, fy: h.y + k * 30, sx: 0, sy: 0, tx: 0, ty: 0, t: 1 });
  return {
    col: C.c, tiered: true, reel: true, pts: () => [h, ab],
    click(px, py) { ring(px, py, 150, C.w); traps.push({ x: px, y: py, l: 1 }); boost = 1; for (let i = 0; i < 12; i++) { const p = rnd(px, py, 130), s = grab(p[0], p[1]); s && web(s, { x: px, y: py }); } },
    update() {
      if (fr % 8 == 0) { let n = 0; for (const d of debris) if (d.pull) n++; if (n < 4) for (const d of debris) if (!d.pull) { d.pull = .08; break; } }
      if (fr % 70 == 0) bridge(h);
      steer(h, 3); trail.push({ x: h.x, y: h.y }); if (trail.length > 60) trail.shift();
      ab.a = Math.atan2(h.y - ab.y, h.x - ab.x); ab.x = h.x - Math.cos(ab.a) * 26; ab.y = h.y - Math.sin(ab.a) * 26;
      if (fr % 12 == 0 && webs.length < 8) { const p = rnd(h.x, h.y, 190), s = grab(p[0], p[1]); s && web(s, h); }
      for (const l of legs) {
        const rx = h.x + Math.cos(h.a + l.ang) * l.L, ry = h.y + Math.sin(h.a + l.ang) * l.L;
        if (l.t >= 1) { if (Math.hypot(rx - l.fx, ry - l.fy) > l.L * .5) { l.sx = l.fx; l.sy = l.fy; l.tx = rx + Math.cos(h.a) * 12; l.ty = ry + Math.sin(h.a) * 12; l.t = 0; } }
        else { l.t = Math.min(1, l.t + .13); l.fx = l.sx + (l.tx - l.sx) * l.t; l.fy = l.sy + (l.ty - l.sy) * l.t; if (l.t >= 1) { threads.push({ x1: l.sx + scrollX, y1: l.sy + scrollY, x2: l.fx + scrollX, y2: l.fy + scrollY, b: performance.now(), c: C.w }); if (threads.length > 140) threads.shift(); } }
      }
    },
    draw() {
      x.strokeStyle = C.w; x.lineWidth = 1.5;
      for (let i = 1; i < trail.length; i++) { x.globalAlpha = i / trail.length * .5; x.beginPath(); line(trail[i - 1].x, trail[i - 1].y, trail[i].x, trail[i].y); x.stroke(); }
      x.lineWidth = .6; x.strokeStyle = C.c; x.globalAlpha = .45; x.beginPath();
      legs.forEach((l, i) => { line(h.x, h.y, l.fx, l.fy); if (i % 4) line(l.fx, l.fy, legs[i - 1].fx, legs[i - 1].fy); });
      x.stroke(); x.globalAlpha = 1; x.lineWidth = 1.2;
      for (const l of legs) {
        const kx = (h.x + l.fx) / 2 - Math.sin(h.a) * l.k * 26, ky = (h.y + l.fy) / 2 + Math.cos(h.a) * l.k * 26;
        x.strokeStyle = C.c; x.beginPath(); line(h.x, h.y, kx, ky); x.lineTo(l.fx, l.fy); x.stroke();
        x.fillStyle = C.g; x.beginPath(); x.arc(l.fx, l.fy, l.t < 1 ? 3.5 : 2.5, 0, 7); x.fill();
        x.fillStyle = C.c; x.beginPath(); x.arc(kx, ky, 2, 0, 7); x.fill();
      }
      for (const [b, w, hh] of [[ab, 30, 22], [h, 18, 14]]) {
        x.save(); x.translate(b.x, b.y); x.rotate(b.a); const cw = w / 3, ch = hh / 2;
        for (let i = 0; i < 3; i++) for (let j = 0; j < 2; j++) { x.fillStyle = b === h ? C.r : ((i + j) % 2 ? '#0a0a0a' : C.g); x.fillRect(-w / 2 + i * cw, -hh / 2 + j * ch, cw, ch); }
        x.strokeStyle = C.c; x.lineWidth = 1.5; x.strokeRect(-w / 2, -hh / 2, w, hh); x.restore();
      }
    }
  };
}

// ---------- EMBER ----------
function ember() {
  const w = walker(), fb = []; let cd = 30;
  const throwF = (dir, d) => fb.push({ x: w.x + dir * 12, y: w.y - 22, vx: dir * 6.5, vy: -1 - d, b: 0, age: 0 });
  return {
    col: C.o, needsPlats: true, eat: 22, pts: () => [{ x: w.x, y: w.y - 14 }],
    click(px) { const dir = px >= w.x ? 1 : -1; w.face = dir; for (let i = 0; i < 3; i++) setTimeout(() => throwF(dir, i * 1.2), i * 90); ring(w.x, w.y - 20, 60, C.o); },
    update() {
      phys(w, 4.2, 12);
      if (w.hit > 6) { const s = grab(w.x, w.y + 4); if (s) { wipe(s, 'coin', { g: .45, vx: (R() - .5) * 3, vy: -6, col: C.y }); ring(w.x, w.y, 45, C.y); w.vy = -7; w.ground = false; } }
      if (--cd <= 0) { throwF(w.face, 0); cd = 38; }
      for (let i = fb.length - 1; i >= 0; i--) {
        const f = fb[i]; f.age++; f.vy += .5; const py = f.y; f.x += f.vx; f.y += f.vy;
        if (f.vy > 0) { let hitP = f.y >= H ? { t: H } : null; for (const p of plats) if (f.x > p.l && f.x < p.r && py <= p.t + 1 && f.y >= p.t) { hitP = p; break; } if (hitP) { f.y = hitP.t; f.vy = -6.5; f.b++; } }
        let dead = f.age > 220 || f.b > 5 || f.x < -20 || f.x > W + 20;
        if (!dead && f.age % 2 == 0) { const s = grab(f.x, f.y); if (s) { wipe(s, 'coin', { g: .45, vx: f.vx * .4, vy: -5, col: C.y }); burst(f.x, f.y, 14, C.o); dead = true; } }
        if (dead) fb.splice(i, 1);
      }
    },
    draw(now) {
      x.save(); x.translate(w.x, w.y); x.scale(w.face, 1);
      const sw = w.ground ? Math.sin(w.x * .3) * 5 * Math.min(1, Math.abs(w.vx) / 2) : 6;
      x.fillStyle = '#3a2a1a'; x.fillRect(-6 + sw, -5, 6, 5); x.fillRect(1 - sw, -5, 6, 5);
      x.fillStyle = '#2b4cff'; x.fillRect(-6, -14, 13, 10); x.fillStyle = '#ff7a1a'; x.fillRect(-7, -24, 15, 11);
      x.fillStyle = '#ffcf9f'; x.beginPath(); x.arc(1, -30, 7, 0, TAU); x.fill(); x.fillRect(7, -24, 6 + (cd > 30 ? 4 : 0), 4);
      x.fillStyle = '#ff3d00'; x.beginPath(); x.moveTo(-7, -32); x.quadraticCurveTo(-2, -48, 4, -42); x.quadraticCurveTo(7, -46, 9, -32); x.closePath(); x.fill();
      x.fillStyle = C.y; x.beginPath(); x.moveTo(-2, -33); x.quadraticCurveTo(1, -42, 4, -33); x.fill();
      x.fillStyle = '#222'; x.fillRect(4, -32, 2, 3); x.restore();
      for (const f of fb) { x.save(); x.shadowColor = C.o; x.shadowBlur = 12; x.fillStyle = C.o; x.beginPath(); x.arc(f.x, f.y, 6, 0, TAU); x.fill(); x.fillStyle = C.y; x.beginPath(); x.arc(f.x, f.y, 3, 0, TAU); x.fill(); x.restore(); }
    }
  };
}

// ---------- ZIP ----------
function zip() {
  const w = walker(); let st = 'run', ct = 0, rt = 0, cdD = 0, cdH = 0, homing = null, spin = 0;
  const dash = dir => { st = 'charge'; ct = 0; w.face = dir; };
  return {
    col: '#18b9c9', needsPlats: true, eat: 22, pts: () => [{ x: w.x, y: w.y - 12 }],
    click(px) { dash(px >= w.x ? 1 : -1); ring(w.x, w.y - 12, 60, '#18b9c9'); },
    update() {
      cdD--; cdH--; spin += .5;
      if (st === 'run') {
        phys(w, 6.5, 12);
        if (Math.abs(tx - w.x) > 260 && w.ground && cdD <= 0) dash(Math.sign(tx - w.x));
        if (!w.ground && !homing && cdH <= 0) { let best = null, bd = 150; for (const p of plats) { const px = Math.max(p.l, Math.min(p.r, w.x)), d = Math.hypot(px - w.x, p.t - w.y); if (d > 40 && d < bd) { bd = d; best = { x: px, y: p.t + 3 }; } } if (best) homing = { x: best.x, y: best.y, t: 10 }; }
        if (homing) { const dx = homing.x - w.x, dy = homing.y - (w.y - 10), d = Math.hypot(dx, dy) || 1; w.vx = dx / d * 12; w.vy = dy / d * 12; if (--homing.t <= 0 || d < 14) { const s = grab(homing.x, homing.y); if (s) wipe(s, 'ring', { g: .35, vy: -6, col: C.y }); homing = null; cdH = 50; w.vy = -8; } }
      } else if (st === 'charge') { phys(w, 0, 0, true); w.vx = 0; if (++ct > 24) { st = 'roll'; rt = 0; w.vx = w.face * 15; } }
      else { phys(w, 0, 0, true); w.vx *= w.ground ? .985 : 1; rt++; if (fr % 2 == 0) { const p = rnd(w.x, w.y - 12, 14), s = grab(p[0], p[1]); if (s) wipe(s, 'ring', { g: .35, vy: -6, col: C.y }); } if (Math.abs(w.vx) < 3 || rt > 90) { st = 'run'; cdD = 60; } }
      this.st = st;
    },
    draw(now) {
      x.save(); x.translate(w.x, w.y);
      if (st !== 'run') {
        x.translate(0, -12); x.rotate(spin * (st === 'roll' ? 1.2 : 2.4) * w.face);
        for (let i = 0; i < 6; i++) { x.rotate(TAU / 6); x.fillStyle = '#0e8c9a'; x.beginPath(); x.moveTo(8, -4); x.lineTo(19, 0); x.lineTo(8, 4); x.fill(); }
        x.fillStyle = '#18b9c9'; x.beginPath(); x.arc(0, 0, 11, 0, TAU); x.fill(); x.strokeStyle = '#fff'; x.lineWidth = 1.5; x.stroke();
        x.restore(); if (st === 'charge') { x.strokeStyle = C.w; x.lineWidth = 1; x.beginPath(); for (let i = 0; i < 4; i++) { const a = R() * TAU; line(w.x + Math.cos(a) * 14, w.y - 12 + Math.sin(a) * 14, w.x + Math.cos(a) * 26, w.y - 12 + Math.sin(a) * 26); } x.stroke(); } return;
      }
      x.scale(w.face, 1);
      x.fillStyle = '#0e8c9a'; for (let i = 0; i < 3; i++) { x.beginPath(); x.moveTo(-8, -20 - i * 5); x.lineTo(-22, -14 - i * 6); x.lineTo(-7, -13 - i * 5); x.fill(); }
      const run = Math.abs(w.vx) > 3, sw = Math.sin(now / 50) * 7;
      x.fillStyle = '#ff6a1a'; if (run) { x.beginPath(); x.ellipse(0, -3, 12, 4, 0, 0, TAU); x.fill(); } else { x.fillRect(-7, -5, 7, 5); x.fillRect(1, -5, 7, 5); }
      x.fillStyle = '#18b9c9'; x.beginPath(); x.arc(0, -17, 11, 0, TAU); x.fill();
      x.fillStyle = '#ffd9b3'; x.beginPath(); x.ellipse(5, -15, 6, 7, 0, 0, TAU); x.fill();
      x.fillStyle = '#fff'; x.beginPath(); x.arc(5, -22, 4, 0, TAU); x.fill(); x.fillStyle = '#111'; x.fillRect(6, -23, 2, 3); x.restore();
    }
  };
}

// ---------- CHOMP ----------
function chomp() {
  const c = { x: W / 2, y: H / 2, dx: 1, dy: 0, turn: 0, power: 0 };
  return {
    col: C.y, eat: 20, pts: () => [c],
    click(px, py) { c.power = 300; ring(c.x, c.y, 110, C.y); burst(c.x, c.y, 24, C.y); },
    update() {
      if (--c.turn <= 0) { const ex = tx - c.x, ey = ty - c.y; if (Math.hypot(ex, ey) > 14) { if (Math.abs(ex) > Math.abs(ey)) { c.dx = Math.sign(ex); c.dy = 0; } else { c.dx = 0; c.dy = Math.sign(ey); } } else { c.dx = 0; c.dy = 0; } c.turn = 16; }
      const sp = (c.power > 0 ? 4.6 : 3.4) * (1 + boost); c.x += c.dx * sp; c.y += c.dy * sp; if (c.power > 0) c.power--;
      c.x = Math.max(12, Math.min(W - 12, c.x)); c.y = Math.max(12, Math.min(H - 12, c.y));
      if (fr % 2 == 0) {
        const r = c.power > 0 ? 24 : 14, n = c.power > 0 ? 4 : 2;
        for (let i = 0; i < n; i++) { const p = rnd(c.x + c.dx * r, c.y + c.dy * r, r), s = grab(p[0], p[1]); if (s) wipe(s, 'dot', { vx: 0, vy: 0, col: C.y }); }
      }
    },
    draw(now) {
      const sc = c.power > 0 ? 1.7 : 1, m = .05 + Math.abs(Math.sin(now / 90)) * .9, ang = Math.atan2(c.dy, c.dx || (c.dy ? 0 : 1));
      x.save(); x.translate(c.x, c.y); x.rotate(c.dx || c.dy ? ang : 0); x.scale(sc, sc);
      x.fillStyle = c.power > 0 && fr % 8 < 4 ? C.o : C.y; x.beginPath(); x.moveTo(0, 0); x.arc(0, 0, 14, m, TAU - m); x.closePath(); x.fill();
      x.fillStyle = '#111'; x.beginPath(); x.arc(2, -7, 2, 0, TAU); x.fill(); x.restore();
    }
  };
}

// ---------- STICK GANG ----------
const SCOL = { orange: '#ff8a1f', red: '#ff3b3b', green: '#3ddc5a', yellow: '#ffe135', blue: '#3b82ff' };
function freeze(s) {
  if (s.dataset.t || s.dataset.f) return; s.dataset.f = 1;
  const st = s.style; st.setProperty('color', '#aeeaff', 'important'); st.setProperty('text-shadow', '0 0 8px #aeeaff', 'important'); st.setProperty('background', 'rgba(174,234,255,.25)', 'important');
  setTimeout(() => { if (s.isConnected) wipe(s, 'boom', { col: '#aeeaff' }); }, 1100);
}
const knock = (s, vx, vy) => wipe(s, 'label', { g: .5, vx, vy });
function stickFig(kind, idx) {
  const col = SCOL[kind], w = walker(), shots = [], bolts = []; w.x = W * (.15 + idx * .17); w.tx = w.x; w.ty = H / 2; let cd = 20 + idx * 9, atk = 0, cdB = 0;
  const shoot = (vx, vy, type) => shots.push({ x: w.x + w.face * 14, y: w.y - 24, vx, vy, type, life: 120, stuck: 0 });
  const bolt = (px, py) => {
    const pts = [[px + (R() - .5) * 30, 0]], n = 8; for (let i = 1; i <= n; i++) pts.push([px + (R() - .5) * 24, py * i / n]); pts[n] = [px, py]; bolts.push({ pts, l: 12 });
    const s = grab(px, py); if (s) wipe(s, 'boom', { col }); for (let k = 0; k < 2; k++) { const p = rnd(px, py, 70), s2 = grab(p[0], p[1]); if (s2) wipe(s2, 'boom', { col }); } ring(px, py, 50, col);
  };
  const act = (px, py) => {
    const f = w.face; atk = 14;
    if (kind === 'orange') { for (let i = 0; i < 6; i++) { const a = -1.3 + i * .45, s = grab(w.x + f * Math.cos(a) * 42, w.y - 24 + Math.sin(a) * 42); if (s) knock(s, f * 5, -5); } shoot(f * 9, 0, 'wave'); }
    else if (kind === 'red') { if (w.ground) { w.vy = -13; w.ground = false; w.pound = true; } }
    else if (kind === 'green') { for (const d of [-.14, 0, .14]) shoot(f * 11 * Math.cos(d), -1 + Math.sin(d) * 11, 'arrow'); }
    else if (kind === 'yellow') { const p = px != null ? [px, py] : rnd(w.x, w.y - 20, 260); bolt(p[0], p[1]); }
    else for (const d of [-.15, 0, .15]) shoot(f * 9 * Math.cos(d), Math.sin(d) * 9, 'ice');
  };
  return {
    pt: () => ({ x: w.x, y: w.y - 14 }), setTarget(a, b) { w.tx = a; w.ty = b; }, special: act,
    update() {
      phys(w, kind === 'yellow' ? 6.2 : kind === 'red' ? 4.4 : 5, 12);
      if (--cd <= 0) { act(); cd = kind === 'red' ? 90 : kind === 'yellow' ? 70 : kind === 'orange' ? 44 : 52; }
      if (atk > 0) atk--;
      if (w.pound && w.hit > 6) { w.pound = false; ring(w.x, w.y, 130, col); burst(w.x, w.y, 24, col); for (let k = 0; k < 14; k++) { const s = grab(w.x + (R() - .5) * 260, w.y - R() * 40); if (s) knock(s, (s.getBoundingClientRect().left - w.x) * .05, -8); } }
      if (kind === 'green' && --cdB <= 0 && w.ground && w.ty < w.y - 50) { temps.push({ l: w.x + w.face * 10 - 18, r: w.x + w.face * 10 + 18, t: w.y - 58, life: 360 }); cdB = 70; }
      for (let i = shots.length - 1; i >= 0; i--) {
        const a = shots[i]; if (a.stuck) { if (--a.stuck <= 0) shots.splice(i, 1); continue; }
        if (a.type !== 'wave') a.vy += a.type === 'arrow' ? .08 : .02; a.x += a.vx; a.y += a.vy; a.life--;
        let s = grab(a.x + Math.sign(a.vx || 1) * 8, a.y); if (!s && a.type === 'wave') s = grab(a.x, a.y - 16) || grab(a.x, a.y + 16);
        if (s) { if (a.type === 'ice') { freeze(s); burst(a.x, a.y, 8, '#aeeaff'); a.stuck = 1; } else { knock(s, a.vx * .4, -4); if (a.type === 'arrow') { a.stuck = 30; a.vx = 0; a.vy = 0; } } }
        if (a.life <= 0 || a.x < -30 || a.x > W + 30) shots.splice(i, 1);
      }
      for (let i = bolts.length - 1; i >= 0; i--) if (--bolts[i].l <= 0) bolts.splice(i, 1);
    },
    draw() {
      x.save(); x.translate(w.x, w.y); x.scale(w.face, 1); x.strokeStyle = col; x.fillStyle = col; x.lineWidth = 3.2; x.lineCap = 'round';
      const mv = w.ground ? Math.sin(w.x * .28) * 8 * Math.min(1, Math.abs(w.vx) / 2) : 8, ext = atk > 0 ? atk / 14 : 0;
      x.beginPath(); line(0, -14, -mv, 0); line(0, -14, mv, 0); line(0, -14, 0, -30); line(0, -27, -8, -18); line(0, -27, 10 + ext * 6, -24); x.stroke();
      x.beginPath(); x.arc(0, -36, 6, 0, TAU); x.stroke(); x.lineWidth = 2.5;
      if (kind === 'orange') { x.strokeStyle = '#fff3d6'; x.shadowColor = col; x.shadowBlur = 8; x.beginPath(); line(10, -24, 30, -38 + ext * 26); x.stroke(); if (ext) { x.globalAlpha = ext; x.strokeStyle = col; x.beginPath(); x.arc(0, -26, 44, -1.3, 1.1); x.stroke(); } }
      else if (kind === 'green') { x.strokeStyle = '#c98a3a'; x.beginPath(); x.arc(14, -24, 12, -1.2, 1.2); x.stroke(); }
      else if (kind === 'blue') { x.fillStyle = '#aeeaff'; x.shadowColor = '#aeeaff'; x.shadowBlur = 8; x.beginPath(); x.moveTo(12, -24); x.lineTo(17, -34); x.lineTo(22, -24); x.lineTo(17, -20); x.closePath(); x.fill(); }
      else if (kind === 'red') { if (!w.ground) { x.shadowColor = col; x.shadowBlur = 10; x.beginPath(); x.arc(12, -24, 5, 0, TAU); x.fill(); } }
      else if (atk > 0) { x.strokeStyle = '#fff'; x.shadowColor = col; x.shadowBlur = 10; x.beginPath(); for (let i = 0; i < 5; i++) line(R() * 20 - 10, -44 + R() * 40, R() * 20 - 10, -44 + R() * 40); x.stroke(); }
      x.restore();
      for (const a of shots) {
        if (a.type === 'wave') { x.save(); x.translate(a.x, a.y); x.scale(Math.sign(a.vx) || 1, 1); x.strokeStyle = col; x.shadowColor = col; x.shadowBlur = 10; x.lineWidth = 3; x.beginPath(); x.arc(-14, 0, 18, -1, 1); x.stroke(); x.restore(); }
        else if (a.type === 'ice') { x.fillStyle = '#aeeaff'; x.fillRect(a.x - 4, a.y - 2, 8, 4); }
        else { x.strokeStyle = C.w; x.lineWidth = 2; x.beginPath(); line(a.x - Math.sign(a.vx || 1) * 12, a.y, a.x, a.y + a.vy); x.stroke(); }
      }
      for (const b of bolts) { x.save(); x.strokeStyle = '#fff'; x.shadowColor = col; x.shadowBlur = 14; x.lineWidth = 2.5; x.globalAlpha = b.l / 12; x.beginPath(); x.moveTo(b.pts[0][0], b.pts[0][1]); for (const p of b.pts) x.lineTo(p[0], p[1]); x.stroke(); x.restore(); }
    }
  };
}
function gang(kinds) {
  const figs = kinds.map((k, i) => stickFig(k, kinds.length === 1 ? 2 : i)); figs.forEach(f => { f.wt = 0; });
  return {
    col: SCOL[kinds[0]], needsPlats: true, eat: 0, pts: () => figs.map(f => f.pt()),
    click(px, py) { figs.forEach(f => f.special(px, py)); },
    update(now) { figs.forEach((f, i) => { if (now - last < 3500) f.setTarget(tx + (i - (figs.length - 1) / 2) * 70, ty); else if (--f.wt <= 0) { f.setTarget(40 + R() * (W - 80), 40 + R() * (H - 80)); f.wt = 140 + R() * 140 | 0; } f.update(); }); },
    draw(now) { figs.forEach(f => f.draw(now)); }
  };
}

// ---------- pixel characters ----------
const PXC = ['#8b5a2b', '#7a7a7a', '#4caf50', '#ffd54f', '#5ac8fa'];
function pix(rows, pal, ox, oy, sz) { for (let j = 0; j < rows.length; j++) for (let i = 0; i < rows[j].length; i++) { const c = pal[rows[j][i]]; if (c) { x.fillStyle = c; x.fillRect(ox + i * sz, oy + j * sz, sz, sz); } } }

// STARSHIP: Free-roaming floating flight across the full screen
function starship() {
  const s = { x: W / 2, y: H / 2 }, bl = []; let cd = 0, beam = 0, bx = 0;
  const SHIP = ['.....c.....', '....cwc....', '....cwc....', '...ccwcc...', '.c.ccwcc.c.', '.cccccccccc', 'ccrcccccrcc', 'cc.ccwcc.cc', 'c...r.r...c'], PAL2 = { c: '#27d3c3', w: '#ffffff', r: '#ff4d4d' };
  return {
    col: C.c, eat: 0, pts: () => [s],
    click() { beam = 36; bx = s.x; ring(s.x, s.y, 80, C.c); },
    update() {
      s.x += (tx - s.x) * .08; s.y += (ty - s.y) * .08;
      s.x = Math.max(20, Math.min(W - 20, s.x)); s.y = Math.max(20, Math.min(H - 20, s.y));
      if (--cd <= 0) { bl.push({ x: s.x - 8, y: s.y - 14, vy: -12 }, { x: s.x + 8, y: s.y - 14, vy: -12 }); cd = 12; }
      if (beam > 0) { beam--; for (let i = 0; i < 6; i++) { const w = grab(bx + (R() - .5) * 48, R() * s.y); if (w) wipe(w, 'boom', { col: PXC[R() * 5 | 0], vx: (R() - .5) * 3, vy: 2 }); } }
      for (let i = bl.length - 1; i >= 0; i--) {
        const b = bl[i]; b.y += b.vy; const w = grab(b.x, b.y - 4);
        if (w) { wipe(w, 'boom', { col: PXC[R() * 5 | 0], vx: (R() - .5) * 3, vy: 2 }); burst(b.x, b.y, 6, C.w); bl.splice(i, 1); } else if (b.y < -10 || b.y > H + 10) bl.splice(i, 1);
      }
    },
    draw(now) {
      if (beam > 0) { x.save(); x.globalAlpha = Math.min(1, beam / 12) * .55; x.fillStyle = C.c; x.shadowColor = C.c; x.shadowBlur = 14; x.fillRect(bx - 22, 0, 44, s.y); x.restore(); }
      pix(SHIP, PAL2, s.x - 16.5, s.y - 13.5, 3);
      if (fr % 6 < 3) { x.fillStyle = C.y; x.fillRect(s.x - 8, s.y + 14, 3, 6); x.fillRect(s.x + 5, s.y + 14, 3, 6); }
      x.fillStyle = C.w; for (const b of bl) x.fillRect(b.x - 1.5, b.y - 6, 3, 9);
    }
  };
}

// TANK: Free-roaming top-down movement across the entire screen
function tank() {
  const c = { x: W / 2, y: H / 2, dx: 0, dy: -1, turn: 0 }, sh = []; let cd = 10, anim = 0, mvg = false;
  const fire = (dx, dy) => sh.push({ x: c.x + dx * 16, y: c.y + dy * 16, dx, dy, age: 0 });
  return {
    col: '#c4d450', eat: 0, pts: () => [c],
    click() { fire(1, 0); fire(-1, 0); fire(0, 1); fire(0, -1); ring(c.x, c.y, 70, '#c4d450'); },
    update() {
      const ex = tx - c.x, ey = ty - c.y; mvg = Math.hypot(ex, ey) > 14;
      if (--c.turn <= 0 && mvg) { if (Math.abs(ex) > Math.abs(ey)) { c.dx = Math.sign(ex); c.dy = 0; } else { c.dx = 0; c.dy = Math.sign(ey); } c.turn = 14; }
      if (mvg) { const sp = 3.2 * (1 + boost); c.x += c.dx * sp; c.y += c.dy * sp; anim++; }
      c.x = Math.max(14, Math.min(W - 14, c.x)); c.y = Math.max(14, Math.min(H - 14, c.y));
      if (--cd <= 0) { fire(c.dx, c.dy); cd = 22; }
      for (let i = sh.length - 1; i >= 0; i--) {
        const b = sh[i]; b.x += b.dx * 8; b.y += b.dy * 8; b.age++; const w = grab(b.x + b.dx * 6, b.y + b.dy * 6);
        if (w) { wipe(w, 'boom', { col: ['#c4d450', '#8a9a3a', '#7a7a7a'][R() * 3 | 0], vx: b.dx * 3 + (R() - .5) * 2, vy: b.dy * 3 + (R() - .5) * 2 }); burst(b.x, b.y, 10, C.y); sh.splice(i, 1); }
        else if (b.age > 90 || b.x < -10 || b.x > W + 10 || b.y < -10 || b.y > H + 10) sh.splice(i, 1);
      }
    },
    draw() {
      x.save(); x.translate(c.x, c.y); x.rotate(Math.atan2(c.dx, -c.dy));
      x.fillStyle = '#3d4a1a'; x.fillRect(-11, -11, 5, 22); x.fillRect(6, -11, 5, 22);
      x.fillStyle = '#8a9a3a'; for (let i = 0; i < 5; i++) { const o = ((anim * 2 + i * 5) % 22) - 11; x.fillRect(-11, o, 5, 2); x.fillRect(6, o, 5, 2); }
      x.fillStyle = '#a9ba46'; x.fillRect(-6, -9, 12, 18); x.fillStyle = '#c4d450'; x.fillRect(-4, -4, 8, 8); x.fillStyle = '#556018'; x.fillRect(-1.5, -17, 3, 13); x.restore();
      x.fillStyle = C.y; for (const b of sh) x.fillRect(b.x - 2, b.y - 2, 4, 4);
    }
  };
}

// MINER: Fully integrated jetpack/grapple free-roaming mode so it never gets stuck at the bottom
function miner() {
  const w = walker(), bombs = [], arrows = [], orbs = [], inv = [0, 0, 0, 0, 0]; let sw = 0, cd = 14, tool = 0, cdHook = 0, hook = null;
  const BODY = ['..hhhh..', '.hhhhhh.', '.ffffff.', '.feffef.', '.ffffff.', '..bbbb..', '.bbbbbb.', 'fbbbbbbf', '.bbbbbb.', '..pppp..', '..pppp..'], LEG = ['..p..p..', '..p..p..', '.kk..kk.'], LEG2 = ['.p....p.', '.p....p.', 'kk....kk'];
  const PAL3 = { h: '#8b4a1b', f: '#ffcf9f', e: '#222', b: '#3a8cff', p: '#4b4b9b', k: '#2a2a2a' };
  const mine = (px, py) => { const s = grab(px, py); if (s) wipe(s, 'px', { col: PXC[R() * 5 | 0], vx: (R() - .5) * 4, vy: -3, g: .45 }); return !!s; };
  const slot = i => W / 2 - 87 + i * 29;
  const icon = (i, cx, cy) => {
    x.save(); x.translate(cx, cy);
    if (i === 0) { x.fillStyle = '#7a4a1e'; x.fillRect(-1, -8, 2, 16); x.fillStyle = '#b8c4cc'; x.fillRect(-8, -9, 16, 3); }
    else if (i === 1) { x.fillStyle = '#dfe9f2'; x.fillRect(-1.5, -9, 3, 13); x.fillStyle = '#7a4a1e'; x.fillRect(-4, 4, 8, 2); x.fillRect(-1, 6, 2, 3); }
    else if (i === 2) { x.strokeStyle = '#c98a3a'; x.lineWidth = 2; x.beginPath(); x.arc(2, 0, 8, -1.2, 1.2); x.stroke(); x.strokeStyle = '#fff'; x.lineWidth = 1; x.beginPath(); line(2 + Math.cos(-1.2) * 8, Math.sin(-1.2) * 8, 2 + Math.cos(1.2) * 8, Math.sin(1.2) * 8); x.stroke(); }
    else if (i === 3) { x.fillStyle = '#7a4a1e'; x.fillRect(-1, -4, 2, 12); x.fillStyle = '#b36bff'; x.beginPath(); x.arc(0, -6, 4, 0, TAU); x.fill(); }
    else if (i === 4) { x.fillStyle = '#d33'; x.fillRect(-5, -6, 10, 12); x.fillStyle = '#222'; x.fillRect(-5, -6, 10, 2); }
    else { x.strokeStyle = '#aab'; x.lineWidth = 2; x.beginPath(); x.arc(0, 2, 6, .4, 3.6); x.stroke(); x.fillStyle = '#aab'; x.fillRect(-1, -8, 2, 6); }
    x.restore();
  };
  const useTool = (t, ux, uy) => {
    const f = w.face;
    if (t === 0) { sw = 12; for (let r = 12; r <= 40; r += 7) mine(w.x + ux * r, w.y - 18 + uy * r); }
    else if (t === 1) { sw = 12; for (let i = 0; i < 7; i++) { const a = -1.3 + i * .4; mine(w.x + f * Math.cos(a) * 40, w.y - 22 + Math.sin(a) * 40); } }
    else if (t === 2) { sw = 8; arrows.push({ x: w.x + f * 14, y: w.y - 22, vx: ux * 11, vy: uy * 11 - 1, life: 120, stuck: 0 }); }
    else if (t === 3) { sw = 8; orbs.push({ x: w.x + f * 14, y: w.y - 24, vx: ux * 5, vy: uy * 5, age: 0 }); }
    else if (t === 5) { hook = { x: tx, y: ty, t: 24 }; cdHook = 60; }
  };
  return {
    col: '#ffb84d', needsPlats: false, eat: 24, mag: 70, pts: () => [{ x: w.x, y: w.y - 14 }],
    got(d) { const i = PXC.indexOf(d.c); if (i >= 0) inv[i]++; },
    click() { tool = 4; bombs.push({ x: w.x, y: w.y - 24, vx: w.face * 5, vy: -7, t: 70 }); cd = 30; },
    update() {
      cdHook--;
      // Free floating flight physics so miner never gets stuck
      const dx = tx - w.x, dy = ty - w.y, dist = Math.hypot(dx, dy) || 1;
      if (dist > 30) { w.vx += (dx / dist) * .45; w.vy += (dy / dist) * .45; }
      w.vx *= .92; w.vy *= .92;
      w.x += w.vx; w.y += w.vy;
      w.x = Math.max(20, Math.min(W - 20, w.x)); w.y = Math.max(20, Math.min(H - 20, w.y));
      w.face = dx >= 0 ? 1 : -1;

      if (hook) { w.x += (hook.x - w.x) * .2; w.y += (hook.y - w.y) * .2; if (--hook.t <= 0) hook = null; }
      if (--cd <= 0) {
        let ux = dx / dist, uy = dy / dist;
        tool = dist < 80 ? (R() < .5 ? 0 : 1) : cdHook <= 0 ? 5 : 2;
        useTool(tool, ux, uy); cd = 22;
      }
      if (sw > 0) sw--;
      for (let i = arrows.length - 1; i >= 0; i--) {
        const a = arrows[i]; if (a.stuck) { if (--a.stuck <= 0) arrows.splice(i, 1); continue; }
        a.vy += .08; a.x += a.vx; a.y += a.vy; a.life--;
        if (mine(a.x + Math.sign(a.vx || 1) * 8, a.y)) { a.stuck = 30; a.vx = 0; a.vy = 0; }
        if (a.life <= 0 || a.x < -20 || a.x > W + 20) arrows.splice(i, 1);
      }
      for (let i = orbs.length - 1; i >= 0; i--) {
        const o = orbs[i]; o.age++; const odx = tx - o.x, ody = ty - o.y, od = Math.hypot(odx, ody) || 1; o.vx += odx / od * .25; o.vy += ody / od * .25;
        o.x += o.vx; o.y += o.vy; let boom = o.age > 140;
        if (!boom && mine(o.x, o.y)) { for (let k = 0; k < 5; k++) { const p = rnd(o.x, o.y, 34); mine(p[0], p[1]); } ring(o.x, o.y, 40, '#b36bff'); burst(o.x, o.y, 12, '#b36bff'); boom = true; }
        if (boom) orbs.splice(i, 1);
      }
      for (let i = bombs.length - 1; i >= 0; i--) {
        const b = bombs[i]; b.vy += .3; b.x += b.vx; b.y += b.vy; b.t--;
        if (b.t <= 0) { ring(b.x, b.y, 100, '#ff6a1a'); burst(b.x, b.y, 30, '#ff9a3a'); for (let k = 0; k < 16; k++) { const p = rnd(b.x, b.y, 100); mine(p[0], p[1]); } bombs.splice(i, 1); }
      }
    },
    draw(now) {
      x.save(); x.globalCompositeOperation = 'lighter'; const g = x.createRadialGradient(w.x, w.y - 20, 4, w.x, w.y - 20, 100); g.addColorStop(0, 'rgba(255,200,110,.28)'); g.addColorStop(1, 'rgba(255,200,110,0)'); x.fillStyle = g; x.fillRect(w.x - 100, w.y - 120, 200, 200); x.restore();
      if (hook) { x.strokeStyle = '#aab'; x.lineWidth = 1.5; x.beginPath(); line(w.x, w.y - 20, hook.x, hook.y); x.stroke(); x.fillStyle = '#aab'; x.fillRect(hook.x - 3, hook.y - 3, 6, 6); }
      x.save(); x.translate(w.x, w.y); x.scale(w.face, 1);
      pix(BODY, PAL3, -8, -28, 2); pix(LEG, PAL3, -8, -6, 2);
      x.save(); x.translate(6, -16);
      if (tool === 0) { x.rotate(sw > 0 ? -1.3 : -.5); x.fillStyle = '#7a4a1e'; x.fillRect(0, -1, 16, 2); x.fillStyle = '#b8c4cc'; x.fillRect(13, -6, 3, 12); }
      else if (tool === 1) { x.rotate(sw > 0 ? -1.5 : -.4); x.fillStyle = '#dfe9f2'; x.fillRect(2, -1.5, 20, 3); }
      else if (tool === 2) { x.strokeStyle = '#c98a3a'; x.lineWidth = 2; x.beginPath(); x.arc(8, 0, 11, -1.2, 1.2); x.stroke(); }
      else if (tool === 3) { x.fillStyle = '#b36bff'; x.beginPath(); x.arc(17, 0, 4, 0, TAU); x.fill(); }
      else { x.fillStyle = '#d33'; x.fillRect(4, -5, 8, 10); }
      x.restore(); x.restore();
      for (const a of arrows) { x.strokeStyle = C.w; x.lineWidth = 2; x.beginPath(); line(a.x - Math.sign(a.vx || 1) * 12, a.y, a.x, a.y + a.vy); x.stroke(); }
      for (const o of orbs) { x.save(); x.shadowColor = '#b36bff'; x.shadowBlur = 12; x.fillStyle = '#b36bff'; x.fillRect(o.x - 4, o.y - 4, 8, 8); x.restore(); }
      for (const b of bombs) { x.fillStyle = '#d33'; x.fillRect(b.x - 4, b.y - 4, 8, 8); }
      // hotbar + inventory
      for (let i = 0; i < 6; i++) { const hx = slot(i); x.fillStyle = 'rgba(20,30,70,.75)'; x.fillRect(hx, 10, 26, 26); x.strokeStyle = i === tool ? C.y : 'rgba(255,255,255,.35)'; x.lineWidth = i === tool ? 2 : 1; x.strokeRect(hx, 10, 26, 26); icon(i, hx + 13, 23); }
      x.font = '10px monospace'; let ix = slot(0); for (let i = 0; i < 5; i++) if (inv[i]) { x.fillStyle = PXC[i]; x.fillRect(ix, 42, 8, 8); x.fillStyle = '#fff'; x.fillText(inv[i], ix + 10, 50); ix += 14 + String(inv[i]).length * 6; }
    }
  };
}

const KINDS = ['centipede', 'spider', 'ember', 'zip', 'chomp', 'gang', 'ship', 'tank', 'miner'];
const make = () => {
  const k = species === 'random' ? KINDS[R() * KINDS.length | 0] : species;
  return k === 'ship' ? starship() : k === 'tank' ? tank() : k === 'miner' ? miner() : k === 'spider' ? spider() : k === 'ember' ? ember() : k === 'zip' ? zip() : k === 'chomp' ? chomp() : SCOL[k] ? gang([k]) : k === 'gang' ? gang(['orange', 'red', 'green', 'yellow', 'blue']) : centipede();
};

// ---------- loop ----------
function size() {
  W = innerWidth; H = innerHeight; D = Math.min(devicePixelRatio || 1, 2);
  cv.width = W * D; cv.height = H * D; cv.style.width = W + 'px'; cv.style.height = H + 'px'; x.setTransform(D, 0, 0, D, 0, 0); makeLedges();
}
const mv = e => { tx = e.clientX; ty = e.clientY; last = performance.now(); };
const pd = e => { mv(e); ring(tx, ty, 90, C.c); crit && crit.click && crit.click(tx, ty); };
const mt = e => { const t = e.touches[0]; if (t) { tx = t.clientX; ty = t.clientY; last = performance.now(); } };
const sc = () => { platT = 0; };

function start() { if (on) return; on = true; try { startInner(); console.log('[Crawlers] started'); } catch (e) { console.error('[Crawlers] failed to start', e); } }
function startInner() {
  host = document.createElement('div');
  host.style.cssText = 'all:initial;position:fixed;inset:0;z-index:2147483647;pointer-events:none';
  const sr = host.attachShadow({ mode: 'closed' });
  cv = document.createElement('canvas'); cv.style.cssText = 'position:fixed;left:0;top:0;pointer-events:none';
  sr.append(cv); x = cv.getContext('2d'); document.documentElement.append(host); size();
  tx = W / 2; ty = H / 2; crit = make();
  addEventListener('resize', size); addEventListener('scroll', sc, { passive: true, capture: true });
  addEventListener('pointermove', mv, { passive: true });
  addEventListener('pointerdown', pd, { passive: true, capture: true });
  addEventListener('touchstart', mt, { passive: true }); addEventListener('touchmove', mt, { passive: true });
  raf = requestAnimationFrame(f);
}
function stop() {
  if (!on) return; on = false; cancelAnimationFrame(raf); host && host.remove(); restoreAll();
  removeEventListener('resize', size); removeEventListener('scroll', sc, true); removeEventListener('pointermove', mv);
  removeEventListener('pointerdown', pd, true);
  removeEventListener('touchstart', mt); removeEventListener('touchmove', mt);
}

function f(now) {
  if (!on) return; raf = requestAnimationFrame(f);
  if (document.hidden) return;
  fr++;
  if (crit.needsPlats && now - platT > 700) { buildPlats(); platT = now; }
  if (now - last > 3000) { tx = W / 2 + Math.sin(now / 1700) * W * .38; ty = H / 2 + Math.cos(now / 1300) * H * .36; }
  const ox = scrollX, oy = scrollY;
  if (now - last > 1500 && debris.length) { const q = crit.pts()[0]; let best, bd = 1e9; for (const d of debris) { const dd = Math.hypot(q.x - (d.px - ox), q.y - (d.py - oy)); if (dd < bd) { bd = dd; best = d; } } if (best) { tx = best.px - ox; ty = best.py - oy; } }
  boost *= .95; crit.update(now);
  const pts = crit.pts(), hd = pts[0], sux = debris.length >= 5; let sucking = false;
  if (fr % 25 == 0) hitVisual(hd.x, hd.y);
  x.clearRect(0, 0, W, H);
  threads = threads.filter(t => { const age = now - t.b; if (age > 6000) return false; x.globalAlpha = .45 * (1 - age / 6000); x.strokeStyle = t.c; x.lineWidth = .8; x.beginPath(); line(t.x1 - ox, t.y1 - oy, t.x2 - ox, t.y2 - oy); x.stroke(); return true; });
  traps = traps.filter(t => { t.l -= .018; if (t.l <= 0) return false; x.save(); x.globalAlpha = t.l; x.strokeStyle = C.w; x.lineWidth = 1; x.beginPath(); for (let i = 0; i < 8; i++) { const a = i * TAU / 8; line(t.x, t.y, t.x + Math.cos(a) * 130, t.y + Math.sin(a) * 130); } for (let r = 30; r <= 130; r += 25) { for (let i = 0; i < 8; i++) { const a = i * TAU / 8, b = a + TAU / 8; line(t.x + Math.cos(a) * r, t.y + Math.sin(a) * r, t.x + Math.cos(b) * r, t.y + Math.sin(b) * r); } } x.stroke(); x.restore(); return true; });
  webs = webs.filter(z => {
    if (!z.s.isConnected) return false; z.l++;
    const b = z.s.getBoundingClientRect(), cx = b.left + b.width / 2, cy = b.top + b.height / 2, sx = z.p.x, sy = z.p.y;
    x.save(); x.strokeStyle = C.w; x.globalAlpha = .85; x.lineWidth = 1; x.beginPath(); x.moveTo(sx, sy); x.quadraticCurveTo((sx + cx) / 2 + Math.sin(z.l * .6) * 10, (sy + cy) / 2 + Math.cos(z.l * .6) * 10, cx, cy);
    line(b.left, b.top, b.right, b.bottom); line(b.right, b.top, b.left, b.bottom); x.rect(b.left - 1, b.top - 1, b.width + 2, b.height + 2); x.stroke(); x.restore();
    if (z.l >= 18) { wipe(z.s, 'label', { pull: true, col: C.w, vx: 0, vy: 0 }); return false; } return true;
  });
  bridges = bridges.filter(br => {
    if (!br.a.isConnected || !br.b.isConnected) return false;
    br.l++; const A = br.a.getBoundingClientRect(), B = br.b.getBoundingClientRect(), ax = A.left + A.width / 2, ay = A.top + A.height / 2, bx = B.left + B.width / 2, by = B.top + B.height / 2;
    x.save(); x.strokeStyle = C.c; x.shadowColor = C.c; x.shadowBlur = 8;
    if (br.l < 16) { x.lineWidth = 1.6; for (const q of [[ax, ay], [bx, by]]) { x.beginPath(); x.moveTo(br.src.x, br.src.y); for (let i = 1; i < 6; i++) { const t = i / 6; x.lineTo(br.src.x + (q[0] - br.src.x) * t + (R() - .5) * 22, br.src.y + (q[1] - br.src.y) * t + (R() - .5) * 22); } x.lineTo(q[0], q[1]); x.stroke(); } }
    x.globalAlpha = .75; x.lineWidth = 1; x.beginPath(); line(ax, ay, bx, by); x.stroke(); x.fillStyle = C.c; x.fillRect(ax - 3, ay - 3, 6, 6); x.fillRect(bx - 3, by - 3, 6, 6);
    x.globalAlpha = 1; x.fillStyle = '#fff';
    for (const p of br.pulses) { p.p += p.d * .014; if (p.p >= 1 || p.p <= 0) { p.p = Math.max(0, Math.min(1, p.p)); p.d *= -1; swapPair(br); } x.beginPath(); x.arc(ax + (bx - ax) * p.p, ay + (by - ay) * p.p, 3, 0, TAU); x.fill(); }
    x.restore();
    if (br.l > 900) { delete br.a.dataset.b; delete br.b.dataset.b; return false; }
    return true;
  });
  temps = temps.filter(t => --t.life > 0);
  // NOTE: Platform visual debug rendering removed so platforms remain completely invisible!
  debris = debris.filter(d => {
    const age = now - d.b; if (age > (d.k === 'label' ? 4000 : 9000)) return false;
    let sx = d.px - ox, sy = d.py - oy;
    if (d.pull) { d.px += (hd.x + ox - d.px) * d.pull; d.py += (hd.y + oy - d.py) * d.pull; x.save(); x.globalAlpha = .5; x.strokeStyle = C.w; x.lineWidth = 1; x.beginPath(); line(sx, sy, hd.x, hd.y); x.stroke(); x.restore(); }
    else {
      const dx = hd.x - sx, dy = hd.y - sy, dd = Math.hypot(dx, dy) || 1;
      if (crit.vac && (dd < 260 || sux)) {
        const k = sux ? .9 : .4 + (260 - dd) / 260 * 1.1; d.vx += dx / dd * k; d.vy += dy / dd * k; sucking = true;
        const sp = Math.hypot(d.vx, d.vy); if (sp > 12) { d.vx *= 12 / sp; d.vy *= 12 / sp; }
        x.save(); x.globalAlpha = .18; x.strokeStyle = C.c; x.lineWidth = 1; x.beginPath(); line(sx, sy, hd.x, hd.y); x.stroke(); x.restore();
      } else if (crit.mag && dd < crit.mag) {
        const k = .5 + (crit.mag - dd) / crit.mag * 1.2; d.vx += dx / dd * k; d.vy += dy / dd * k;
        const sp = Math.hypot(d.vx, d.vy); if (sp > 10) { d.vx *= 10 / sp; d.vy *= 10 / sp; }
      }
    }
    const er = crit.eat != null ? crit.eat : 26;
    if (er && fr % 2 == 0) for (const p of pts) if ((p.x - sx) ** 2 + (p.y - sy) ** 2 < er * er) { burst(sx, sy, 10, d.c); xp += 2; crit.got && crit.got(d); return false; }
    if (d.g) { d.vy += d.g; if (d.vy > 0) for (const p of plats) if (d.px - ox > p.l && d.px - ox < p.r && sy <= p.t + 2 && sy + d.vy >= p.t) { d.vy *= -.45; d.vx *= .7; break; } }
    if (d.g || Math.abs(d.vx) + Math.abs(d.vy) > .05) { d.px += d.vx; d.py += d.vy; d.vx *= d.g ? .99 : .93; if (!d.g) d.vy *= .93; d.rot += d.vr; d.vr *= .93; }
    sx = d.px - ox; sy = d.py - oy; if (sx < -150 || sx > W + 50 || sy < -40 || sy > H + 60) return true;
    x.save(); x.translate(sx, sy);
    const fade = d.k === 'label' ? (age > 2600 ? Math.max(0, 1 - (age - 2600) / 1400) : 1) : (age > 7000 ? Math.max(0, 1 - (age - 7000) / 2000) : 1); x.globalAlpha = fade;
    if (d.k === 'ring') { x.strokeStyle = C.y; x.lineWidth = 2.5; x.beginPath(); x.arc(0, 0, 6, 0, TAU); x.stroke(); }
    else if (d.k === 'coin') { x.fillStyle = C.y; x.beginPath(); x.ellipse(0, 0, 4 + Math.abs(Math.sin(now / 150)) * 2, 6, 0, 0, TAU); x.fill(); x.strokeStyle = '#a07800'; x.lineWidth = 1; x.stroke(); }
    else if (d.k === 'px') { x.fillStyle = d.c; x.fillRect(-3, -3, 6, 6); x.strokeStyle = 'rgba(0,0,0,.5)'; x.lineWidth = 1; x.strokeRect(-3, -3, 6, 6); }
    else if (d.k === 'dot') { x.fillStyle = C.y; x.beginPath(); x.arc(0, 0, 3, 0, TAU); x.fill(); }
    else { x.rotate(d.rot); x.font = d.font; x.textBaseline = 'middle'; x.fillStyle = 'rgba(0,0,0,.75)'; x.fillRect(0, -d.h / 2, d.w, d.h); x.strokeStyle = d.c; x.lineWidth = 1; x.strokeRect(0, -d.h / 2, d.w, d.h); x.fillStyle = d.c; x.fillText(d.t, 4, 0); }
    x.restore(); return true;
  });
  rings = rings.filter(r => { r.r += (r.m - r.r) * .18; r.l -= .04; if (r.l <= 0) return false; x.globalAlpha = r.l; x.strokeStyle = r.c; x.lineWidth = 2; x.beginPath(); x.arc(r.x, r.y, r.r, 0, TAU); x.stroke(); return true; });
  if (sucking) { x.globalAlpha = .35; x.strokeStyle = C.c; x.lineWidth = 1.5; x.beginPath(); x.arc(hd.x, hd.y, 34 + Math.sin(now / 80) * 5, 0, TAU); x.stroke(); x.globalAlpha = 1; }
  x.globalCompositeOperation = 'lighter';
  parts = parts.filter(p => { p.vy += p.g || 0; p.x += p.vx; p.y += p.vy; p.vx *= .93; p.vy *= p.g ? 1 : .93; p.l -= .03; if (p.l <= 0) return false; x.globalAlpha = p.l; x.fillStyle = p.c; x.fillRect(p.x, p.y, 2.5, 2.5); return true; });
  x.globalCompositeOperation = 'source-over'; x.globalAlpha = 1;
  if (now - last < 4000) { x.globalAlpha = .55; x.strokeStyle = '#9aa7b4'; x.lineWidth = 1; x.beginPath(); x.arc(tx, ty, 24, 0, TAU); x.stroke(); x.globalAlpha = 1; }
  if (crit.tiered) { const T = tierOf(xp); x.save(); x.translate(hd.x, hd.y); x.scale(T.s, T.s); x.translate(-hd.x, -hd.y); crit.draw(now); x.restore(); x.globalAlpha = .85; x.fillStyle = T.c; x.font = '11px system-ui,sans-serif'; x.fillText(T.n, hd.x + 18, hd.y - 20); x.globalAlpha = 1; }
  else crit.draw(now);
}

const store = (api.storage && (api.storage.sync || api.storage.local)) || null;
if (store) {
  try { store.get({ on: true, species: 'random', power: 'random' }).then(v => { species = v.species; power = v.power || 'random'; if (v.on) start(); }).catch(() => start()); } catch (e) { start(); }
  try {
    api.storage.onChanged.addListener(c => {
      if (c.species) { species = c.species.newValue; if (on) { crit = make(); plats = []; platT = 0; } }
      if (c.power) power = c.power.newValue || 'random';
      if (c.reset) restoreAll();
      if (c.on) c.on.newValue ? start() : stop();
    });
  } catch (e) {}
} else start();
})();